#!/usr/bin/env python3
"""No-deps AUTHLOCK validator (v0.3).

Validates core invariants without external libraries:
- Required fields present
- Enums valid
- Bindingness rules for caselaw classes
- Snapshot presence
- FILE_READY strict rules
- Optional: child_support propositions must reference MCL + MCSF_MANUAL

Usage:
  python validator/validate_authlock.py --root . --mode FILE_READY
"""

from __future__ import annotations
import argparse, json, os, sys
import datetime

AUTH_CLASS = {
  "CONST_MI_1963","MCL","MCR","MRE","ARMC","AO_MSC","CJConduct_MI","JTC_Materials_MI",
  "SCAO_FORMS","SCAO_PUBLICATION","MJI_BENCHBOOK","MCSF_MANUAL","M_CIV_JI","LAO_LOCAL",
  "CASE_MI_SCT_OPINION","CASE_MI_COA_PUBLISHED","CASE_MI_COA_UNPUBLISHED","ORDER_MI_SCT_PRECEDENTIAL",
  "ORDER_IN_CASE_FILESTAMPED","JUDGMENT_IN_CASE_FILESTAMPED","STIPULATED_ORDER_IN_CASE","ROA_DOCKET_ENTRY","TRANSCRIPT_RULING_FINDINGS"
}
BINDINGNESS = {"BINDING","BINDING_IN_CASE_ONLY","PERSUASIVE_ONLY","OPERATIONAL_GUIDANCE","UNKNOWN"}
VERIF = {"VERIFIED","CANDIDATE","UNKNOWN"}
MODE = {"DRAFT","FILE_READY"}


def is_date(s: str) -> bool:
    try:
        datetime.date.fromisoformat(s)
        return True
    except Exception:
        return False


def read_jsonl(path: str):
    out = []
    if not os.path.exists(path):
        return out
    with open(path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception as e:
                raise ValueError(f"Invalid JSON on line {i} in {path}: {e}")
    return out


def add(findings, level, where, msg, obj_id=None):
    findings.append({"level": level, "where": where, "id": obj_id, "msg": msg})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--mode", default="FILE_READY", choices=sorted(MODE))
    args = ap.parse_args()

    root = os.path.abspath(args.root)
    out_dir = os.path.join(root, "validator_out")
    os.makedirs(out_dir, exist_ok=True)

    findings = []
    ok = True

    auth_path = os.path.join(root, "authority_refs.jsonl")
    snap_path = os.path.join(root, "authority_snapshot.json")
    prop_path = os.path.join(root, "propositions.jsonl")

    auth = read_jsonl(auth_path)
    props = read_jsonl(prop_path)

    snap = None
    if os.path.exists(snap_path):
        try:
            with open(snap_path, "r", encoding="utf-8") as f:
                snap = json.load(f)
        except Exception as e:
            ok = False
            add(findings, "FAIL", "AuthoritySnapshot", f"Invalid JSON: {e}")
    else:
        ok = False
        add(findings, "FAIL", "AuthoritySnapshot", "Missing authority_snapshot.json")

    if snap:
        sid = snap.get("snapshot_id")
        as_of = snap.get("as_of_date")
        if not sid:
            ok = False; add(findings, "FAIL", "AuthoritySnapshot", "snapshot_id required")
        if not as_of or not isinstance(as_of, str) or not is_date(as_of):
            ok = False; add(findings, "FAIL", "AuthoritySnapshot", "as_of_date must be YYYY-MM-DD")
        sources = snap.get("sources")
        if not isinstance(sources, list) or not sources:
            ok = False; add(findings, "FAIL", "AuthoritySnapshot", "sources[] required and non-empty")

    auth_by_id = {}
    for row in auth:
        rid = row.get("id")
        if not rid or not isinstance(rid, str):
            ok = False
            add(findings, "FAIL", "AuthorityRef", "id required")
            continue
        if rid in auth_by_id:
            ok = False
            add(findings, "FAIL", "AuthorityRef", "duplicate id", rid)
            continue
        auth_by_id[rid] = row

        cls = row.get("authority_class")
        if cls not in AUTH_CLASS:
            ok = False
            add(findings, "FAIL", "AuthorityRef", f"invalid authority_class: {cls}", rid)

        cit = row.get("citation")
        if not cit or not isinstance(cit, str):
            ok = False
            add(findings, "FAIL", "AuthorityRef", "citation required", rid)

        b = row.get("bindingness")
        if b not in BINDINGNESS:
            ok = False
            add(findings, "FAIL", "AuthorityRef", f"invalid bindingness: {b}", rid)

        pr = row.get("precedence_rank")
        if not isinstance(pr, int) or pr < 1:
            ok = False
            add(findings, "FAIL", "AuthorityRef", "precedence_rank must be int >=1", rid)

        snap_id = row.get("snapshot_id")
        if not snap_id:
            ok = False
            add(findings, "FAIL", "AuthorityRef", "snapshot_id required", rid)
        elif snap and snap.get("snapshot_id") and snap_id != snap.get("snapshot_id"):
            add(findings, "WARN", "AuthorityRef", f"snapshot_id mismatch vs authority_snapshot.json ({snap.get('snapshot_id')})", rid)

        rdate = row.get("retrieved_date")
        if not rdate or not isinstance(rdate, str) or not is_date(rdate):
            ok = False
            add(findings, "FAIL", "AuthorityRef", "retrieved_date must be YYYY-MM-DD", rid)

        v = row.get("verification")
        if v not in VERIF:
            ok = False
            add(findings, "FAIL", "AuthorityRef", f"invalid verification: {v}", rid)

        # Caselaw rules
        if cls == "CASE_MI_COA_UNPUBLISHED":
            if b != "PERSUASIVE_ONLY":
                ok = False
                add(findings, "FAIL", "AuthorityRef", "unpublished COA must be PERSUASIVE_ONLY", rid)
            if row.get("requires_unpublished_explanation") is not True:
                ok = False
                add(findings, "FAIL", "AuthorityRef", "unpublished COA requires requires_unpublished_explanation=true", rid)

        if cls == "CASE_MI_COA_PUBLISHED":
            if b != "BINDING":
                ok = False
                add(findings, "FAIL", "AuthorityRef", "published COA must be BINDING", rid)
            if row.get("is_published") is not True:
                ok = False
                add(findings, "FAIL", "AuthorityRef", "published COA requires is_published=true", rid)

        if cls == "ORDER_MI_SCT_PRECEDENTIAL":
            if b != "BINDING":
                ok = False
                add(findings, "FAIL", "AuthorityRef", "precedential MSC order must be BINDING", rid)
            if row.get("msc_order_final_disposition") is not True or row.get("msc_order_has_concise_facts_and_reasons") is not True:
                ok = False
                add(findings, "FAIL", "AuthorityRef", "precedential MSC order requires final_disposition=true and has_concise_facts_and_reasons=true", rid)

        # FILE_READY strictness
        if args.mode == "FILE_READY":
            if v != "VERIFIED":
                ok = False
                add(findings, "FAIL", "AuthorityRef", "FILE_READY requires verification=VERIFIED", rid)
            if b == "UNKNOWN":
                ok = False
                add(findings, "FAIL", "AuthorityRef", "FILE_READY forbids bindingness=UNKNOWN", rid)

    # Proposition checks
    for row in props:
        pid = row.get("id")
        if not pid:
            ok = False
            add(findings, "FAIL", "Proposition", "id required")
            continue
        if row.get("mode") not in MODE:
            ok = False
            add(findings, "FAIL", "Proposition", "mode invalid", pid)

        refs = row.get("authority_ref_ids")
        if not isinstance(refs, list) or not refs:
            ok = False
            add(findings, "FAIL", "Proposition", "authority_ref_ids required", pid)
            continue

        for ref_id in refs:
            if ref_id not in auth_by_id:
                ok = False
                add(findings, "FAIL", "Proposition", f"unknown authority_ref_id: {ref_id}", pid)

        if row.get("domain") == "child_support":
            has_mcl = any(auth_by_id[r].get("authority_class") == "MCL" for r in refs if r in auth_by_id)
            has_mcsf = any(auth_by_id[r].get("authority_class") == "MCSF_MANUAL" for r in refs if r in auth_by_id)
            if not (has_mcl and has_mcsf):
                ok = False
                add(findings, "FAIL", "Proposition", "child_support domain requires at least one MCL ref and one MCSF_MANUAL ref", pid)

    report = {
        "version": "AUTHLOCK_VALIDATOR_v0.3",
        "mode": args.mode,
        "root": root,
        "pass": bool(ok),
        "findings": findings
    }

    with open(os.path.join(out_dir, "report.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    print(("PASS" if ok else "FAIL") + ": report written to validator_out/report.json")
    sys.exit(0 if ok else 2)


if __name__ == "__main__":
    main()
