# AUTHLOCK Contracts Bundle v0.3

## Contents
- AUTHLOCK_v0.3.md (spec)
- schemas/*.schema.json (data contracts)
- validator/validate_authlock.py (no-deps validator)
- mbp_worldfirst_builder.py (rebuild bundle locally + receipts)

## Quick start
1) Put your data files next to this README:
   - authority_snapshot.json
   - authority_refs.jsonl
   - propositions.jsonl
2) Run:
   python validator/validate_authlock.py --root . --mode FILE_READY
3) Read:
   validator_out/report.json

## Notes
- Validator is intentionally no-deps to avoid pip friction.
- FILE_READY mode is strict: AuthorityRefs must be VERIFIED and not UNKNOWN bindingness.
