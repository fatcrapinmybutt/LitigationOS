#!/usr/bin/env python3
"""mbp_worldfirst_builder.py (AUTHLOCK bundle v0.3)

Reconstructs the AUTHLOCK contracts bundle on any machine without relying on a sandbox link.
- Copies files shipped next to this builder
- Produces a ZIP
- Emits CRC32 + SHA-256 receipts

Usage:
  python mbp_worldfirst_builder.py --outdir ./AUTHLOCK_OUT
"""

from __future__ import annotations
import argparse, os, zipfile, hashlib, binascii, json

FILES = [
  "AUTHLOCK_v0.3.md",
  "README.md",
  "schemas/authority_ref.schema.json",
  "schemas/authority_snapshot.schema.json",
  "schemas/proposition.schema.json",
  "validator/validate_authlock.py",
]


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def crc32_bytes(b: bytes) -> str:
    return format(binascii.crc32(b) & 0xffffffff, "08x")


def write_file(path: str, content: bytes):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "wb") as f:
        f.write(content)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="AUTHLOCK_OUT")
    args = ap.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))
    outdir = os.path.abspath(args.outdir)
    os.makedirs(outdir, exist_ok=True)

    receipts = []
    for rel in FILES:
        src = os.path.join(here, rel)
        if not os.path.exists(src):
            raise SystemExit(f"Missing source file next to builder: {rel}")
        with open(src, "rb") as f:
            data = f.read()
        dst = os.path.join(outdir, rel)
        write_file(dst, data)
        receipts.append({"path": rel, "bytes": len(data), "crc32": crc32_bytes(data), "sha256": sha256_bytes(data)})

    rec_path = os.path.join(outdir, "AUTHLOCK_contracts_bundle_v0.3.receipts.json")
    with open(rec_path, "w", encoding="utf-8") as f:
        json.dump({"bundle": "AUTHLOCK_contracts_bundle_v0.3", "files": receipts}, f, indent=2)

    zip_path = os.path.join(outdir, "AUTHLOCK_contracts_bundle_v0.3.zip")
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for r in receipts:
            z.write(os.path.join(outdir, r["path"]), arcname=r["path"])
        z.write(rec_path, arcname=os.path.basename(rec_path))

    print("Built:", zip_path)
    print("Receipts:", rec_path)


if __name__ == "__main__":
    main()
