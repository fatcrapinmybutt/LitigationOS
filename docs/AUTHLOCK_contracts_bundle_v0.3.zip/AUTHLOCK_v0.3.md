# AUTHLOCK v0.3 — Michigan-Only Authority Lock (Executable Spec)

**Purpose.** Define a Michigan-first “authority universe” plus enforceable bindingness, snapshot, and proposition-gating rules suitable for GraphRAG/PCW/PCG pipelines.

This version explicitly encodes: (i) Michigan constitutional authority; (ii) Michigan caselaw hierarchy + published/unpublished rules; (iii) administrative rules; (iv) “controlling-in-case” record sources; (v) mandatory domain manuals (e.g., child support formula); (vi) model civil jury instructions; and (vii) a federal overlay exception for explicitly federal vehicles.

---

## 0.1 Authority Universe (MI-default)

### 0.1.1 Michigan statewide authority (default controlling)
**AuthorityClass enum (MI):**
- `CONST_MI_1963`
- `MCL`
- `MCR`
- `MRE`
- `ARMC`  *(Administrative Rules for Michigan Courts; Chapter 8 of MCR book)*
- `AO_MSC` *(Michigan Supreme Court Administrative Orders)*
- `CJConduct_MI` *(Michigan Code of Judicial Conduct)*
- `JTC_Materials_MI` *(JTC process/materials; bindingness depends on item type)*
- `SCAO_FORMS` *(SCAO-approved forms)*
- `SCAO_PUBLICATION` *(SCAO publications; bindingness tagged per rule/order coupling)*
- `MJI_BENCHBOOK` *(MJI benchbooks/checklists/manuals; operational unless coupled)*
- `MCSF_MANUAL` *(Michigan Child Support Formula Manual/Supplements; mandatory-by-statute context)*
- `M_CIV_JI` *(Michigan Model Civil Jury Instructions)*
- `LAO_LOCAL` *(Local Administrative Orders / local rules / standing orders — sourced-only)*

### 0.1.2 Michigan caselaw (typed; bindingness enforced)
**AuthorityClass enum (caselaw):**
- `CASE_MI_SCT_OPINION`
- `CASE_MI_COA_PUBLISHED`
- `CASE_MI_COA_UNPUBLISHED`
- `ORDER_MI_SCT_PRECEDENTIAL` *(MSC orders that qualify as binding precedent)*

### 0.1.3 Controlling-in-case record sources (binding within the case)
These are not statewide authority, but they control the case posture and are required inputs to record-spine discipline:
- `ORDER_IN_CASE_FILESTAMPED`
- `JUDGMENT_IN_CASE_FILESTAMPED`
- `STIPULATED_ORDER_IN_CASE`
- `ROA_DOCKET_ENTRY`
- `TRANSCRIPT_RULING_FINDINGS`

---

## 0.2 Bindingness & Precedence Ladder (machine-checkable)

### 0.2.1 Bindingness enum
- `BINDING`
- `BINDING_IN_CASE_ONLY`
- `PERSUASIVE_ONLY`
- `OPERATIONAL_GUIDANCE`
- `UNKNOWN` *(allowed only in DRAFT/DISCOVERY; blocked in FILE_READY/PCG)*

### 0.2.2 Precedence rank (coarse)
Use an integer `precedence_rank` (lower = stronger):
1. `CONST_MI_1963`
2. `CASE_MI_SCT_OPINION` / `ORDER_MI_SCT_PRECEDENTIAL`
3. `MCL`
4. `MCR` / `MRE` / `ARMC` / `AO_MSC`
5. `CASE_MI_COA_PUBLISHED`
6. `LAO_LOCAL` *(only if authorized + not inconsistent; sourced)*
7. `MCSF_MANUAL` *(mandatory-by-statute context; tag as binding where statute/rule requires)*
8. `SCAO_FORMS` / `SCAO_PUBLICATION` / `MJI_BENCHBOOK` / `M_CIV_JI` *(bindingness depends on coupling)*
9. `CASE_MI_COA_UNPUBLISHED` *(persuasive-only)*

---

## 0.3 Caselaw Gate Rules (enforceable)

Operational rules to encode:
- If `authority_class == CASE_MI_COA_UNPUBLISHED`, then `bindingness` must be `PERSUASIVE_ONLY` and `requires_unpublished_explanation=true`.
- If `authority_class == CASE_MI_COA_PUBLISHED`, then `bindingness` must be `BINDING` and `is_published=true`.
- If `authority_class == ORDER_MI_SCT_PRECEDENTIAL`, require `msc_order_final_disposition=true` and `msc_order_has_concise_facts_and_reasons=true`.

---

## 0.4 Mandatory Domain-Manual Gate (Child Support Formula)

When child support is at issue:
- The statute sets the “formula” baseline requirement.
- The MCSF manual is the operational formula manual/supplement set; deviation logic is implemented via the statute + the manual’s presumption/rebuttal structure.

Operational rule to encode:
- Any proposition tagged `domain=child_support` must cite at least one `MCL` authority ref and one `MCSF_MANUAL` ref unless explicitly flagged `NOT_APPLICABLE`.

---

## 0.5 Federal Overlay Rule (OV)

Default: federal sources are `OV_PERSUASIVE_ONLY` and never treated as controlling in a Michigan-only filing.

Exception: if and only if the selected vehicle is explicitly federal, allow `OV_FED_CONTROLLING_FOR_FED_VEHICLE_ONLY` semantics and store:
- `overlay_scope = "FED_VEHICLE_ONLY"`
- activating `vehicle_id`

---

## 0.6 Data Contracts

### 0.6.1 AuthorityRef (JSONL)
One object per line in `authority_refs.jsonl`.

Required fields:
- `id` (stable string)
- `authority_class` (enum)
- `citation` (string)
- `pinpoint` (string or null; required for caselaw/orders)
- `bindingness` (enum)
- `precedence_rank` (int)
- `snapshot_id` (string)
- `source_url` (string or null)
- `effective_date` (YYYY-MM-DD or null)
- `retrieved_date` (YYYY-MM-DD)
- `verification` (`VERIFIED`|`CANDIDATE`|`UNKNOWN`)
- `notes` (string or null)

Additional fields (conditional):
- `is_published` (bool; required for COA cases)
- `requires_unpublished_explanation` (bool; required for unpublished COA)
- `msc_order_final_disposition` (bool; required for MSC orders)
- `msc_order_has_concise_facts_and_reasons` (bool; required for MSC orders)

### 0.6.2 AuthoritySnapshot (JSON)
File: `authority_snapshot.json`

Required fields:
- `snapshot_id`
- `as_of_date` (YYYY-MM-DD)
- `sources` (array of {`name`,`url`,`retrieved_date`})
- `notes`

### 0.6.3 Proposition (JSONL)
File: `propositions.jsonl`

Required fields:
- `id`
- `text` (proposition statement)
- `vehicle_id` (string)
- `authority_ref_ids` (array of authority ref IDs)
- `mode` (`DRAFT`|`FILE_READY`)
- `domain` (string or null)
- `flags` (array of strings)

---

## 0.7 Schemas + Validator

- Schemas: `schemas/*.schema.json`
- No-deps validator: `validator/validate_authlock.py`
- Output: `validator_out/report.json` (PASS/FAIL + findings)

---

## 0.8 Minimal CLI (validator)
```bash
python validator/validate_authlock.py --root . --mode FILE_READY
```
